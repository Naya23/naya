/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class tugasnaya {
    public static void main(String[] args) {
        String nama ="ABCDEFGHIJKLMNOPQRSTUVWXYZ-";
        System.out.println("" + nama.charAt(13) + nama.charAt(0) + nama.charAt(24) + nama.charAt(0) + nama.charAt(26) + nama.charAt(8) + nama.charAt(13) + nama.charAt(0) + nama.charAt(24) + nama.charAt(0) + nama.charAt(7));
    }
    
}
